# Malayalam IPTV EPG updater

Automatically refreshes the category 255 Malayalam M3U playlist and XMLTV EPG using an Xtream-compatible provider.

## GitHub setup

1. Create a new GitHub repository.
2. Upload these files/folders.
3. Go to **Settings → Secrets and variables → Actions**.
4. Add:
   - `XTREAM_SERVER` = your provider server, e.g. `https://example.com`
   - `XTREAM_USERNAME` = your Xtream username
   - `XTREAM_PASSWORD` = your Xtream password
5. Go to **Actions → Update Malayalam IPTV → Run workflow** once to test it.
6. The workflow then runs every 6 hours and commits:
   - `malayalam.m3u`
   - `malayalam.xml`

Use the **raw** GitHub URLs for those two files in TiviMate.

The workflow also supports manual runs.
